import { useNavigate } from "react-router";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { GraduationCap, Users } from "lucide-react";

export default function Landing() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen relative overflow-hidden flex items-center justify-center p-4" style={{
      background: 'linear-gradient(135deg, #FF6B7A 0%, #FFE680 100%)'
    }}>
      {/* Shell pattern background */}
      <div className="absolute inset-0 opacity-5">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="shell-pattern" x="0" y="0" width="120" height="120" patternUnits="userSpaceOnUse">
              <g transform="translate(60, 60)">
                {/* Shell shape */}
                <path d="M 0,-30 Q 20,-25 25,-10 Q 28,0 25,10 Q 20,25 0,30 Q -20,25 -25,10 Q -28,0 -25,-10 Q -20,-25 0,-30 Z" 
                      fill="white" opacity="0.6"/>
                <path d="M 0,-25 L 0,25 M -15,-15 L 15,15 M 15,-15 L -15,15 M -20,0 L 20,0" 
                      stroke="white" strokeWidth="1.5" opacity="0.4"/>
                <circle cx="0" cy="0" r="5" fill="white" opacity="0.8"/>
              </g>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#shell-pattern)"/>
        </svg>
      </div>

      <div className="max-w-4xl w-full space-y-8 relative z-10">
        <div className="text-center space-y-4">
          <h1 className="text-5xl font-bold text-white drop-shadow-lg">Coach Connect</h1>
          <p className="text-xl text-white/95 drop-shadow">
            Connecting coaches with UMD students
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <Card className="hover:shadow-2xl transition-all hover:scale-105 cursor-pointer border-2 border-white/20 bg-white/95 backdrop-blur" 
                onClick={() => navigate("/coach/onboarding")}>
            <CardHeader className="text-center">
              <div className="mx-auto w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
                <Users className="w-8 h-8 text-red-600" />
              </div>
              <CardTitle className="text-2xl">Sign Up as Coach</CardTitle>
              <CardDescription>
                Find students to teach
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-gray-600 mb-6">
                <li>• Create your coaching profile</li>
                <li>• Offer private lessons</li>
                <li>• Connect with interested students</li>
                <li>• Build your coaching practice</li>
              </ul>
              <Button className="w-full bg-red-600 hover:bg-red-700" size="lg">
                Get Started as Coach
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-2xl transition-all hover:scale-105 cursor-pointer border-2 border-white/20 bg-white/95 backdrop-blur"
                onClick={() => navigate("/student/onboarding")}>
            <CardHeader className="text-center">
              <div className="mx-auto w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mb-4">
                <GraduationCap className="w-8 h-8 text-yellow-600" />
              </div>
              <CardTitle className="text-2xl">Sign Up as Student</CardTitle>
              <CardDescription>
                Find private coaches
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-gray-600 mb-6">
                <li>• Browse qualified coaches</li>
                <li>• Book private lessons</li>
                <li>• Set your athletic goals</li>
                <li>• Start training today</li>
              </ul>
              <Button className="w-full bg-yellow-600 hover:bg-yellow-700" size="lg">
                Get Started as Student
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="text-center pt-6">
          <p className="text-white drop-shadow">
            Already have an account?{" "}
            <button
              onClick={() => navigate("/login")}
              className="font-semibold underline hover:text-white/90 transition-colors"
            >
              Login
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}