import { Button } from "../components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { LogIn } from "lucide-react";

export default function Login() {
  const handleSSOLogin = () => {
    // TODO: Integrate with Google SSO for email verification
    // For now, this is a placeholder that will be replaced with actual Google SSO implementation
    console.log("Google SSO login - to be implemented");
  };

  return (
    <div className="min-h-screen relative overflow-hidden flex items-center justify-center p-4" style={{
      background: 'linear-gradient(135deg, #FF6B7A 0%, #FFE680 100%)'
    }}>
      {/* Shell pattern background */}
      <div className="absolute inset-0 opacity-5">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="shell-pattern" x="0" y="0" width="120" height="120" patternUnits="userSpaceOnUse">
              <g transform="translate(60, 60)">
                {/* Shell shape */}
                <path d="M 0,-30 Q 20,-25 25,-10 Q 28,0 25,10 Q 20,25 0,30 Q -20,25 -25,10 Q -28,0 -25,-10 Q -20,-25 0,-30 Z"
                      fill="white" opacity="0.6"/>
                <path d="M 0,-25 L 0,25 M -15,-15 L 15,15 M 15,-15 L -15,15 M -20,0 L 20,0"
                      stroke="white" strokeWidth="1.5" opacity="0.4"/>
                <circle cx="0" cy="0" r="5" fill="white" opacity="0.8"/>
              </g>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#shell-pattern)"/>
        </svg>
      </div>

      <div className="max-w-md w-full relative z-10">
        <Card className="border-2 border-white/20 bg-white/95 backdrop-blur shadow-2xl">
          <CardHeader className="text-center space-y-4">
            <div className="mx-auto w-20 h-20 bg-gradient-to-br from-red-500 to-yellow-500 rounded-full flex items-center justify-center mb-2">
              <LogIn className="w-10 h-10 text-white" />
            </div>
            <CardTitle className="text-3xl">Welcome Back</CardTitle>
            <CardDescription className="text-base">
              Use the email you have an account associated with
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <Button
              onClick={handleSSOLogin}
              className="w-full h-14 text-lg bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800"
              size="lg"
            >
              <LogIn className="w-5 h-5 mr-2" />
              Google
            </Button>

            <div className="text-center space-y-2">
              <p className="text-xs text-gray-400">
                Students: UMD email required (@terpmail.umd.edu or @umd.edu)<br />
                Coaches: Any email accepted
              </p>
              <div className="pt-4 border-t">
                <p className="text-sm text-gray-600">
                  Don't have an account?{" "}
                  <a href="/" className="text-red-600 hover:text-red-700 font-medium underline">
                    Sign up here
                  </a>
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}