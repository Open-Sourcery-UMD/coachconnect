import { useEffect, useState, useMemo } from "react";
import { useLocation, useNavigate } from "react-router";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { ArrowLeft, LogOut, Mail, Phone, DollarSign, Clock, Star, AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "../components/ui/alert";

interface Coach {
  id: number;
  name: string;
  email: string;
  phone: string;
  expertise: string[];
  bio: string;
  experience: string;
  rate: string;
  availability: string[];
  type: string;
  profilePicture?: string;
  gender?: string;
}

export default function Results() {
  const navigate = useNavigate();
  const location = useLocation();
  const sports = useMemo(() => (location.state?.sports as string[]) || [], [location.state?.sports]);
  const [matchedCoaches, setMatchedCoaches] = useState<Coach[]>([]);

  useEffect(() => {
    // Load coaches from localStorage and filter by sports
    const storedCoaches = JSON.parse(localStorage.getItem("coaches") || "[]") as Coach[];
    
    // Filter coaches that have at least one matching sport
    const filtered = storedCoaches.filter((coach) =>
      coach.expertise.some((sport) => sports.includes(sport))
    );
    
    setMatchedCoaches(filtered);
  }, [sports]);

  const handleConnect = (coach: Coach) => {
    alert(`Connection request sent to ${coach.name}! They will receive your contact information.`);
  };

  return (
    <div className="min-h-screen p-4 relative overflow-hidden" style={{
      background: 'linear-gradient(135deg, #FF6B7A 0%, #FFE680 100%)'
    }}>
      {/* Shell pattern background */}
      <div className="absolute inset-0 opacity-5">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="shell-pattern" x="0" y="0" width="120" height="120" patternUnits="userSpaceOnUse">
              <g transform="translate(60, 60)">
                <path d="M 0,-30 Q 20,-25 25,-10 Q 28,0 25,10 Q 20,25 0,30 Q -20,25 -25,10 Q -28,0 -25,-10 Q -20,-25 0,-30 Z" 
                      fill="white" opacity="0.6"/>
                <path d="M 0,-25 L 0,25 M -15,-15 L 15,15 M 15,-15 L -15,15 M -20,0 L 20,0" 
                      stroke="white" strokeWidth="1.5" opacity="0.4"/>
                <circle cx="0" cy="0" r="5" fill="white" opacity="0.8"/>
              </g>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#shell-pattern)"/>
        </svg>
      </div>

      <div className="max-w-6xl mx-auto space-y-6 relative z-10">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white drop-shadow-lg">Your Matched Coaches</h1>
            <p className="text-white/90 mt-1 drop-shadow">
              Based on your interest in: {sports.length > 0 ? sports.join(", ") : "None selected"}
            </p>
          </div>
          <Button variant="destructive" onClick={() => navigate("/")} className="bg-red-600 hover:bg-red-700">
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>

        {matchedCoaches.length === 0 ? (
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>No Coaches Available</AlertTitle>
            <AlertDescription>
              We couldn't find any coaches for the sports you selected ({sports.join(", ")}). 
              <br />
              Please check back later or try selecting different sports. Coaches are constantly joining our platform!
            </AlertDescription>
          </Alert>
        ) : (
          <div className="space-y-4">
            <p className="text-sm text-gray-600">
              Found {matchedCoaches.length} {matchedCoaches.length === 1 ? "coach" : "coaches"} matching your interests
            </p>
            
            <div className="grid gap-4 md:grid-cols-2">
              {matchedCoaches.map((coach) => (
                <Card key={coach.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-start gap-3 flex-1">
                        {coach.profilePicture && (
                          <img
                            src={coach.profilePicture}
                            alt={coach.name}
                            className="w-16 h-16 object-cover rounded-full border-2 border-gray-200"
                          />
                        )}
                        <div className="flex-1">
                          <CardTitle>{coach.name}</CardTitle>
                          <CardDescription className="flex items-center gap-2 mt-1">
                            {coach.experience && (
                              <span>{coach.experience} years experience</span>
                            )}
                          </CardDescription>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <p className="text-sm text-gray-600 line-clamp-3">{coach.bio}</p>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <DollarSign className="w-4 h-4 text-gray-500" />
                        <span className="font-medium">
                          {coach.rate ? `$${coach.rate}/lesson` : "Contact for pricing"}
                        </span>
                      </div>
                      {coach.email && (
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Mail className="w-4 h-4" />
                          <span>{coach.email}</span>
                        </div>
                      )}
                      {coach.phone && (
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Phone className="w-4 h-4" />
                          <span>{coach.phone}</span>
                        </div>
                      )}
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-2">Sports:</p>
                      <div className="flex flex-wrap gap-1">
                        {coach.expertise.map((exp) => (
                          <Badge 
                            key={exp} 
                            variant={sports.includes(exp) ? "default" : "secondary"}
                          >
                            {exp}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {coach.availability.length > 0 && (
                      <div>
                        <p className="text-sm font-medium mb-2 flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          Lesson Times:
                        </p>
                        <div className="flex flex-wrap gap-1">
                          {coach.availability.map((time) => (
                            <Badge key={time} variant="outline">
                              {time}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    <Button className="w-full" onClick={() => handleConnect(coach)}>
                      Connect with Coach
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}